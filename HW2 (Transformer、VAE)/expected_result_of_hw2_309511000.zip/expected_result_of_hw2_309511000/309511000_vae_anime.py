"""
Code for the VAE (Section 2 of the problem)
"""
